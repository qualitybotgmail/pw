angular.module('starter.config',[])
.constant('API_URL','https://jhoncistalknote.blobby.xyz/')
.constant('BASE_URL','https://jhoncistalknote.blobby.xyz')
.constant('STORAGE_PREFIX','talknote_')
.constant('PWORK_API_URL','http://playwork.urchin.company/api/');
